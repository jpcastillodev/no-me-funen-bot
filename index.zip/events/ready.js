module.exports = bot => {
    console.log('bot online')
}